from django.apps import AppConfig


class CoreModelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_model'
